export type AmplifyDependentResourcesAttributes = {
    "api": {
        "ipcmuireactjs": {
            "GraphQLAPIKeyOutput": "string",
            "GraphQLAPIIdOutput": "string",
            "GraphQLAPIEndpointOutput": "string"
        }
    }
}